$(function(){

$('.review__items').slick({
	centerMode: true,
	centerPadding: '0px',
 slidesToShow: 3,
	autoplay: true,
	autoplaySpeed: 3000,
	arrows: false,
	dots: true,
	responsive: [
		{
				breakpoint: 1000,
				settings: {
						centerPadding: '80px',
						slidesToShow: 1,
				},
		},
		{
			breakpoint: 767,
				settings: {
						slidesToShow: 1,
				}
		}
]
});

jQuery(document).ready(function () {

	$(".phone").mask("999999999999"); 

});

});